# Kholo: bolo ya likho, koi bhi app khul jayega

Ye app **100% free** hai.
- Koi API key nahi chahiye.
- Koi subscription nahi.
- Internet ki zaroorat app ko nahi (voice ke liye aapka phone ka Google voice use hota hai).
- Play Store par daalne ki zaroorat nahi, to wo fees bhi nahi.

Ye aapke phone ke **saare apps** me se naam dhundhta hai, isliye sirf 2-3 apps tak limited nahi hai.

---

## Kya chahiye (sab free)

1. Ek **computer / laptop** (Windows, Mac ya Linux). Ye sirf **ek baar** app banane ke liye chahiye.
2. Aapka **Android phone** aur uski **USB cable**.
3. Internet (Android Studio download karne ke liye). Lagbhag 10 GB jagah.

---

## Step 1: Android Studio install karo

1. Computer par browser kholo, search karo: **Android Studio download**.
2. Official site (developer.android.com/studio) par **Download Android Studio** dabao.
3. File khol kar **Next, Next, Finish** dabate jao. Pehli baar khologe to ye kuch cheezein khud download karega. Intezaar karo.

## Step 2: Naya project banao

1. Android Studio me **New Project** dabao.
2. **Empty Views Activity** chuno, **Next** dabao.
3. Ye bharo:
   - **Name:** `AI Commander`
   - **Package name:** apne aap `com.example.aicommander` ban jayega (ek baar check kar lena, wahi hona chahiye)
   - **Language:** `Kotlin`
   - **Minimum SDK:** `API 26`
4. **Finish** dabao. Neeche ek progress bar chalega. **Jab tak wo khatam na ho, intezaar karo** (2 se 10 minute).

## Step 3: Meri files daalo

1. Ye zip file computer par **Extract** karo.
2. Extract hue folder me **app** folder kholo. Uske andar **src** folder hai. Is **src** ko copy karo.
3. Apna naya project ka folder kholo (Android Studio me **File > Open Recent** me path dikhta hai, ya project banate waqt **Save location** me dikha tha). Uske andar **app** folder me jao.
4. Wahan **paste** karo. Jab computer puchhe "Replace files?", to **Replace** (ya "Yes to all") dabao.
5. Android Studio par wapas aao. Upar agar **Sync Now** dikhe to dabao. Intezaar karo.

## Step 4: Phone taiyaar karo

1. Phone me **Settings > About phone** kholo.
2. **Build number** par **7 baar** tap karo. "Aap developer ban gaye" likha aayega.
3. Wapas Settings me jao. **Developer options** (ya System > Developer options) kholo.
4. **USB debugging** ko **ON** karo.
5. Phone ko USB cable se computer se jodo. Phone par "Allow USB debugging?" aayega, **Allow** dabao.

## Step 5: App chalao

1. Android Studio ke upar ek dropdown me aapke phone ka naam dikhna chahiye.
2. Uske paas wala hara **▶ (Run)** button dabao.
3. Thodi der me **Kholo** app aapke phone me install hokar khul jayega.

Ab cable nikaal sakte ho. App phone me hamesha rahega.

## Kaise use karo

1. **Mic** dabao aur bolo, ya neeche likhkar **Chalao** dabao.
2. Neeche "Bolne ki bhasha" se हिंदी ya English chuno.

Examples:
- `WhatsApp kholo`
- `YouTube par Kishore Kumar search karo`
- `Spotify par Kesariya chalao`
- `Maps me petrol pump dhundo`
- `Settings kholo`
- हिंदी me bhi: `व्हाट्सएप खोलो`

## Dusre phone me bhi daalna ho (APK)

Android Studio me **Build > Build Bundle(s) / APK(s) > Build APK(s)** dabao. Ban jaye to **locate** dabao. `app-debug.apk` file milegi. Isko WhatsApp ya USB se kisi bhi Android phone par bhej kar install kar sakte ho (phone "Unknown sources / Install unknown apps" allow maangega).

---

## Kya kaam karta hai aur kya limit hai (sach sach)

- **Koi bhi app kholna:** phone me jo bhi app hai, uska naam bolo, khul jayega.
- **App ke andar search:** YouTube, YouTube Music, Spotify, Maps, Chrome, Amazon, Flipkart, JioSaavn me seedha search khulta hai. Baaki apps me app khul jata hai aur aapka likha text **copy** ho jata hai, search box me bas **paste** karna hota hai (kyunki wo apps bahar se search nahi lene deti).
- **Music play:** kuch apps (jaise YouTube Music) seedha gaana chala deti hain. Spotify jaisi apps kabhi sirf search screen kholti hain.
- Command samajhne wala hissa simple rules par chalta hai (AI nahi). Normal English, Hindi aur Hinglish commands samajh aati hain, par bahut ulte-seedhe vakya kabhi nahi samajh aate.

## Problem aaye to

- **Phone dropdown me nahi dikh raha:** cable badlo, phone me USB mode **File transfer** karo, USB debugging dobara ON karo.
- **Gradle / Sync error:** internet check karo, phir **Try Again** dabao.
- **"Theme.Material3 not found" error:** `app/build.gradle.kts` kholo, `dependencies` ke andar `implementation("com.google.android.material:material:1.12.0")` jodo, phir **Sync Now**.
- **Mic dabane par kuch nahi hota:** phone me **Google** app update karo, ya tab tak likhkar use karo.
- **Koi app nahi mil raha:** app ka naam jaisa phone me dikhta hai waise bolo. Hindi me kam chale to English ka option try karo.
