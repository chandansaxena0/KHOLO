package com.example.aicommander

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import kotlin.concurrent.thread

/**
 * Always-on listener. Runs as a foreground service (notification stays visible),
 * so it keeps working when the screen is locked or the app is closed.
 * Everything runs on the phone: no internet, no cost.
 */
class ListenService : Service(), RecognitionListener {

    companion object {
        const val ACTION_LISTEN_NOW = "com.example.aicommander.LISTEN_NOW"
        const val ACTION_STOP = "com.example.aicommander.STOP"
        const val CH_LISTEN = "kholo_listen"
        const val CH_RESULT = "kholo_result"
        const val NOTIF_ID = 1
        const val RESULT_ID = 2
        private const val ARMED_MS = 8000L

        @Volatile
        var running = false
    }

    private val main = Handler(Looper.getMainLooper())
    private var model: Model? = null
    private var speech: SpeechService? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var foregroundStarted = false
    private var armedUntil = 0L
    private lateinit var index: AppIndex
    private lateinit var parser: CommandParser

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
        index = AppIndex(this)
        parser = CommandParser(index)
        index.refresh()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            getSharedPreferences("kholo", MODE_PRIVATE).edit().putBoolean("wake", false).apply()
            stopSelf()
            return START_NOT_STICKY
        }

        if (!foregroundStarted) {
            try {
                ServiceCompat.startForeground(
                    this, NOTIF_ID, buildNotification("Taiyaar ho raha hoon..."),
                    if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
                )
                foregroundStarted = true
            } catch (e: Exception) {
                stopSelf()
                return START_NOT_STICKY
            }
            running = true
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "kholo:listen").apply { acquire() }
            loadModelAndListen()
        }

        if (intent?.action == ACTION_LISTEN_NOW) arm()
        return START_STICKY
    }

    private fun loadModelAndListen() {
        thread {
            try {
                val dir = ModelFiles.ensure(this)
                val m = Model(dir.absolutePath)
                main.post {
                    if (!running) {
                        m.close()
                        return@post
                    }
                    model = m
                    startRecognizer()
                }
            } catch (e: Exception) {
                main.post { fail("Voice model load nahi hua: ${e.message}") }
            }
        }
    }

    private fun startRecognizer() {
        try {
            val rec = Recognizer(model, 16000.0f)
            val s = SpeechService(rec, 16000.0f)
            s.startListening(this)
            speech = s
            updateNotification("Sun raha hoon. Bolo: \"Hey Kholo\"")
        } catch (e: Exception) {
            fail("Mic shuru nahi hua: ${e.message}")
        }
    }

    // ---- RecognitionListener ----
    override fun onResult(hypothesis: String?) {
        val text = try {
            JSONObject(hypothesis ?: return).optString("text", "").trim()
        } catch (e: Exception) {
            ""
        }
        if (text.isNotEmpty()) handleText(text)
    }

    override fun onPartialResult(hypothesis: String?) {}
    override fun onFinalResult(hypothesis: String?) {}
    override fun onError(exception: Exception?) {
        fail("Sunne me error: ${exception?.message}")
    }

    override fun onTimeout() {}

    private fun handleText(text: String) {
        val armed = SystemClock.elapsedRealtime() < armedUntil
        val afterWake = parser.stripWake(text)
        when {
            afterWake != null && afterWake.isBlank() -> arm()
            afterWake != null -> runCommand(afterWake)
            armed -> runCommand(text)
            else -> { /* normal talking, ignore */ }
        }
    }

    /** Wake word heard: beep and wait for the command. */
    private fun arm() {
        armedUntil = SystemClock.elapsedRealtime() + ARMED_MS
        beep()
        updateNotification("Boliye, sun raha hoon...")
        main.postDelayed({
            if (SystemClock.elapsedRealtime() >= armedUntil && armedUntil != 0L) {
                armedUntil = 0L
                updateNotification("Sun raha hoon. Bolo: \"Hey Kholo\"")
            }
        }, ARMED_MS + 200)
    }

    private fun runCommand(text: String) {
        armedUntil = 0L
        index.refresh()
        val cmd = parser.parse(text)
        withOverlay {
            val msg = ActionExecutor.run(this, index, cmd)
            updateNotification("Suna: \"${cmd.heard}\"")
            showResult(cmd, msg)
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        }
    }

    /**
     * Android blocks apps from opening other apps while in the background.
     * A tiny invisible window ("Display over other apps") lets this app do it.
     */
    private fun withOverlay(block: () -> Unit) {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        var view: View? = null
        if (Settings.canDrawOverlays(this)) {
            try {
                val v = View(this)
                val lp = WindowManager.LayoutParams(
                    1, 1,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT
                )
                wm.addView(v, lp)
                view = v
            } catch (e: Exception) {
                view = null
            }
        }
        main.postDelayed({
            block()
            view?.let { v ->
                main.postDelayed({
                    try {
                        wm.removeView(v)
                    } catch (e: Exception) {
                    }
                }, 2500)
            }
        }, if (view != null) 150L else 0L)
    }

    private fun beep() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, 150)
            main.postDelayed({ tg.release() }, 400)
        } catch (e: Exception) {
        }
        try {
            val vib = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            vib.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) {
        }
    }

    private fun fail(message: String) {
        updateNotification(message)
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    // ---- notifications ----
    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_LISTEN, "Kholo sun raha hai", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_RESULT, "Kholo natija", NotificationManager.IMPORTANCE_DEFAULT).apply {
                setSound(null, null)
            }
        )
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val listenNow = PendingIntent.getService(
            this, 1, Intent(this, ListenService::class.java).setAction(ACTION_LISTEN_NOW),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 2, Intent(this, ListenService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CH_LISTEN)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("Kholo")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(0, "Abhi suno", listenNow)
            .addAction(0, "Band karo", stop)
            .build()
    }

    private fun updateNotification(text: String) {
        if (!foregroundStarted) return
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    /** If Android still blocks the launch, this notification opens the app with one tap. */
    private fun showResult(cmd: Command, msg: String) {
        val pkg = cmd.app?.pkg
        val launch = pkg?.let { packageManager.getLaunchIntentForPackage(it) }
        val b = NotificationCompat.Builder(this, CH_RESULT)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle(msg)
            .setContentText(if (launch != null) "Nahi khula? Yahan tap karo." else "")
            .setAutoCancel(true)
            .setTimeoutAfter(15000)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
        if (launch != null) {
            b.setContentIntent(
                PendingIntent.getActivity(
                    this, 3, launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
        }
        getSystemService(NotificationManager::class.java).notify(RESULT_ID, b.build())
    }

    override fun onDestroy() {
        running = false
        speech?.stop()
        speech?.shutdown()
        speech = null
        model?.close()
        model = null
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (e: Exception) {
        }
        super.onDestroy()
    }
}
