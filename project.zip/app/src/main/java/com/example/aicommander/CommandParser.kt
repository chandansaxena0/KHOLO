package com.example.aicommander

enum class Kind { OPEN, SEARCH, PLAY, UNKNOWN }

data class Command(
    val kind: Kind,
    val app: AppInfo?,
    val query: String,
    val heard: String
)

/**
 * Understands commands in English, Hindi and Hinglish WITHOUT any internet or AI service.
 * Idea: find the verb (open / search / play), find which installed app is named,
 * and treat whatever words are left as the thing to search or play.
 */
class CommandParser(private val index: AppIndex) {

    // Multi-word names -> one word (applied first)
    private val phrases = listOf(
        "फोन पे" to "phonepe",
        "गूगल पे" to "google pay",
        "यू ट्यूब" to "youtube",
        "गूगल मैप्स" to "maps",
        "गूगल मैप" to "maps",
        "you tube music" to "youtube music",
        "you tube" to "youtube",
        "google maps" to "maps",
        "google map" to "maps",
        "whats app" to "whatsapp",
        "what s app" to "whatsapp",
        "play store" to "playstore",
        "jio saavn" to "jiosaavn",
        "jio savan" to "jiosaavn",
        "phone pe" to "phonepe",
        "pay tm" to "paytm",
        "face book" to "facebook",
        "insta gram" to "instagram",
        "tele gram" to "telegram"
    )

    // Hindi (Devanagari) word -> Latin word. Voice typing in Hindi often gives these.
    private val words = mapOf(
        // actions
        "खोलो" to "kholo", "खोल" to "khol", "खोलिए" to "kholo", "ओपन" to "open",
        "चलाओ" to "chalao", "चला" to "chala", "चलाइए" to "chalao",
        "बजाओ" to "bajao", "बजा" to "baja", "सुनाओ" to "sunao", "सुना" to "suna",
        "लगाओ" to "lagao", "लगा" to "laga", "प्ले" to "play",
        "सर्च" to "search", "ढूंढो" to "dhundo", "ढूँढो" to "dhundo",
        "खोजो" to "khojo", "दिखाओ" to "dikhao",
        // small words
        "पर" to "par", "पे" to "pe", "में" to "me", "से" to "se",
        "का" to "ka", "की" to "ki", "के" to "ke", "को" to "ko",
        "करो" to "karo", "कर" to "kar", "दो" to "do", "दे" to "de",
        "और" to "aur", "एक" to "ek", "ऐप" to "app", "एप" to "app", "ऐप्प" to "app",
        "गाना" to "gaana", "गाने" to "gaane", "गीत" to "gaane",
        "वीडियो" to "video", "म्यूजिक" to "music", "संगीत" to "music",
        // apps
        "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "वाट्सऐप" to "whatsapp",
        "वॉट्सऐप" to "whatsapp", "वाट्सएप" to "whatsapp", "व्हाट्सअप" to "whatsapp",
        "यूट्यूब" to "youtube", "स्पॉटिफाई" to "spotify", "स्पोटिफाई" to "spotify",
        "स्पोटीफाई" to "spotify", "इंस्टाग्राम" to "instagram", "गूगल" to "google",
        "क्रोम" to "chrome", "मैप्स" to "maps", "मैप" to "maps", "नक्शा" to "maps",
        "फेसबुक" to "facebook", "टेलीग्राम" to "telegram", "पेटीएम" to "paytm",
        "फोनपे" to "phonepe", "जीपे" to "google pay", "अमेज़न" to "amazon",
        "अमेजन" to "amazon", "अमेज़ॉन" to "amazon", "फ्लिपकार्ट" to "flipkart",
        "नेटफ्लिक्स" to "netflix", "जियोसावन" to "jiosaavn", "कैमरा" to "camera",
        "सेटिंग" to "settings", "सेटिंग्स" to "settings", "कैलकुलेटर" to "calculator",
        "गैलरी" to "gallery", "फोटो" to "photos", "फोटोज" to "photos", "घड़ी" to "clock",
        "मैसेज" to "messages", "मैसेजेस" to "messages", "फोन" to "phone",
        "जीमेल" to "gmail", "ड्राइव" to "drive", "स्नैपचैट" to "snapchat",
        "ट्विटर" to "twitter", "ज़ोमैटो" to "zomato", "जोमैटो" to "zomato",
        "स्विगी" to "swiggy", "ओला" to "ola", "उबर" to "uber",
        "लिंक्डइन" to "linkedin", "शेयरचैट" to "sharechat", "हॉटस्टार" to "hotstar"
    )

    private val playVerbs = setOf(
        "play", "chalao", "chala", "chalaiye", "bajao", "baja",
        "sunao", "suna", "lagao", "laga", "chalado"
    )
    private val searchVerbs = setOf(
        "search", "dhundo", "dhoondo", "dhundh", "khojo", "khoj",
        "find", "dikhao", "dikha", "lookup"
    )
    private val openVerbs = setOf(
        "open", "kholo", "khol", "khole", "kholiye", "launch", "start", "chalu", "shuru"
    )
    private val preps = setOf(
        "par", "pe", "me", "mein", "mai", "on", "in", "se", "per",
        "ke", "ki", "ka", "ko", "for", "liye"
    )
    private val fillers = setOf(
        "karo", "kar", "kardo", "karna", "do", "de", "dena", "dijiye", "please", "plz",
        "zara", "mujhe", "mere", "meri", "mera", "app", "application", "aur", "and",
        "the", "a", "ek", "hai", "wala", "wali", "wale", "to", "na", "ya", "jo",
        "kuch", "bhi", "ab", "abhi", "can", "you", "i", "want", "ji"
    )
    // Words that describe the request but are not the name of the song/thing itself
    private val weak = setOf(
        "gaana", "gaane", "gana", "gane", "song", "songs",
        "music", "video", "videos", "vedio", "gaano"
    )

    private val stop: Set<String> = playVerbs + searchVerbs + openVerbs + preps + fillers

    fun parse(raw: String): Command {
        val tokens = tokenize(raw)

        var kind = when {
            tokens.any { it in playVerbs } -> Kind.PLAY
            tokens.any { it in searchVerbs } -> Kind.SEARCH
            tokens.any { it in openVerbs } -> Kind.OPEN
            else -> Kind.UNKNOWN
        }

        // Find the app name: the best matching group of 1 to 3 words
        var app: AppInfo? = null
        var bestScore = 0.0
        var appRange: IntRange = IntRange.EMPTY
        for (start in tokens.indices) {
            if (tokens[start] in stop) continue
            var joined = ""
            for (end in start until minOf(tokens.size, start + 3)) {
                if (tokens[end] in stop) break
                joined += tokens[end]
                val m = index.bestMatch(Normalizer.key(joined)) ?: continue
                if (m.second < 0.85) continue
                var s = m.second + 0.001 * (end - start)
                if (start > 0 && tokens[start - 1] in preps) s += 0.05
                if (end + 1 < tokens.size && tokens[end + 1] in preps) s += 0.05
                if (s > bestScore) {
                    bestScore = s
                    app = m.first
                    appRange = start..end
                }
            }
        }

        // Everything that is not the app, a verb or a filler = what to search / play
        val query = tokens.withIndex()
            .filter { (i, t) -> i !in appRange && t !in stop && t !in weak }
            .joinToString(" ") { it.value }

        if (kind == Kind.UNKNOWN) {
            kind = when {
                app != null && query.isEmpty() -> Kind.OPEN
                app != null -> Kind.SEARCH
                else -> Kind.UNKNOWN
            }
        }

        // For "open": try a looser match if nothing matched well
        if (kind == Kind.OPEN && app == null) {
            val key = Normalizer.key(tokens.filter { it !in stop }.joinToString(""))
            val m = index.bestMatch(key)
            if (m != null && m.second >= 0.6) app = m.first
        }

        return Command(kind, app, query, tokens.joinToString(" "))
    }

    private fun tokenize(raw: String): List<String> {
        var s = " " + raw.lowercase().replace(Regex("[^\\p{L}\\p{M}\\p{N}]+"), " ").trim() + " "
        for ((from, to) in phrases) s = s.replace(" $from ", " $to ")
        return s.trim().split(" ").filter { it.isNotEmpty() }.map { words[it] ?: it }
    }
}
