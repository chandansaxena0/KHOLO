package com.example.aicommander

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {

    private lateinit var index: AppIndex
    private lateinit var parser: CommandParser
    private lateinit var input: TextInputEditText
    private lateinit var status: TextView
    private lateinit var appCount: TextView
    private lateinit var langButton: MaterialButton
    private var hindi = true

    private val speech =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == Activity.RESULT_OK) {
                val spoken = r.data
                    ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                    ?.firstOrNull()
                if (!spoken.isNullOrBlank()) {
                    input.setText(spoken)
                    execute(spoken)
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        index = AppIndex(this)
        parser = CommandParser(index)

        input = findViewById(R.id.commandInput)
        status = findViewById(R.id.statusText)
        appCount = findViewById(R.id.appCountText)
        langButton = findViewById(R.id.langButton)

        findViewById<FloatingActionButton>(R.id.micButton).setOnClickListener { startVoice() }
        findViewById<MaterialButton>(R.id.goButton).setOnClickListener { submitText() }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                submitText()
                true
            } else false
        }

        langButton.setOnClickListener {
            hindi = !hindi
            updateLangButton()
        }
        updateLangButton()

        val chips = findViewById<ChipGroup>(R.id.chipGroup)
        listOf(
            "WhatsApp kholo",
            "YouTube par Kishore Kumar search karo",
            "Spotify par Kesariya chalao",
            "Maps me petrol pump dhundo",
            "Settings kholo"
        ).forEach { example ->
            val chip = Chip(this)
            chip.text = example
            chip.setOnClickListener {
                input.setText(example)
                execute(example)
            }
            chips.addView(chip)
        }
    }

    override fun onResume() {
        super.onResume()
        index.refresh() // pick up newly installed apps
        appCount.text = "${index.apps.size} apps mile. Inme se koi bhi khul sakta hai."
    }

    private fun updateLangButton() {
        langButton.text = if (hindi) "Bolne ki bhasha: हिंदी" else "Bolne ki bhasha: English"
    }

    private fun submitText() {
        val text = input.text?.toString()?.trim().orEmpty()
        if (text.isNotEmpty()) execute(text)
    }

    private fun startVoice() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (hindi) "hi-IN" else "en-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Bolo...")
        }
        try {
            speech.launch(i)
        } catch (e: Exception) {
            status.text = "Is phone me voice input nahi mila. Neeche likhkar try karo."
        }
    }

    private fun execute(text: String) {
        val command = parser.parse(text)
        status.text = ActionExecutor.run(this, index, command)
    }
}
