package com.example.aicommander

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.speech.RecognizerIntent
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {

    private lateinit var index: AppIndex
    private lateinit var parser: CommandParser
    private lateinit var input: TextInputEditText
    private lateinit var status: TextView
    private lateinit var appCount: TextView
    private lateinit var langButton: MaterialButton
    private lateinit var wakeSwitch: MaterialSwitch
    private lateinit var wakeStatus: TextView
    private var hindi = true

    private val prefs by lazy { getSharedPreferences("kholo", MODE_PRIVATE) }
    private var askedPermissions = false
    private var askedOverlay = false
    private var askedBattery = false

    private val speech =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == Activity.RESULT_OK) {
                val spoken = r.data
                    ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                    ?.firstOrNull()
                if (!spoken.isNullOrBlank()) {
                    input.setText(spoken)
                    execute(spoken)
                }
            }
        }

    private val permissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            continueSetup()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        index = AppIndex(this)
        parser = CommandParser(index)

        input = findViewById(R.id.commandInput)
        status = findViewById(R.id.statusText)
        appCount = findViewById(R.id.appCountText)
        langButton = findViewById(R.id.langButton)
        wakeSwitch = findViewById(R.id.wakeSwitch)
        wakeStatus = findViewById(R.id.wakeStatus)

        findViewById<FloatingActionButton>(R.id.micButton).setOnClickListener { startVoice() }
        findViewById<MaterialButton>(R.id.goButton).setOnClickListener { submitText() }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                submitText()
                true
            } else false
        }

        langButton.setOnClickListener {
            hindi = !hindi
            updateLangButton()
        }
        updateLangButton()

        wakeSwitch.setOnCheckedChangeListener { button, checked ->
            if (!button.isPressed) return@setOnCheckedChangeListener
            prefs.edit().putBoolean("wake", checked).apply()
            if (checked) {
                askedPermissions = false
                askedOverlay = false
                askedBattery = false
                continueSetup()
            } else {
                stopService(Intent(this, ListenService::class.java))
                refreshWake()
            }
        }

        val chips = findViewById<ChipGroup>(R.id.chipGroup)
        listOf(
            "WhatsApp kholo",
            "YouTube par Kishore Kumar search karo",
            "Spotify par Kesariya chalao",
            "Maps me petrol pump dhundo",
            "Settings kholo"
        ).forEach { example ->
            val chip = Chip(this)
            chip.text = example
            chip.setOnClickListener {
                input.setText(example)
                execute(example)
            }
            chips.addView(chip)
        }

        // Opened from the "restart" notification: switch listening back on
        if (intent.getBooleanExtra("autostart", false)) {
            prefs.edit().putBoolean("wake", true).apply()
        }
    }

    override fun onResume() {
        super.onResume()
        index.refresh() // pick up newly installed apps
        appCount.text = "${index.apps.size} apps mile. Inme se koi bhi khul sakta hai."
        continueSetup()
        refreshWake()
    }

    // ---- "Hey Kholo" setup: permissions one by one, then start the listener ----
    private fun continueSetup() {
        if (!prefs.getBoolean("wake", false)) {
            refreshWake()
            return
        }

        val need = mutableListOf<String>()
        if (!granted(Manifest.permission.RECORD_AUDIO)) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) {
            need += Manifest.permission.POST_NOTIFICATIONS
        }
        if (need.isNotEmpty() && !askedPermissions) {
            askedPermissions = true
            permissions.launch(need.toTypedArray())
            return
        }
        if (!granted(Manifest.permission.RECORD_AUDIO)) {
            prefs.edit().putBoolean("wake", false).apply()
            Toast.makeText(this, "Mic ki permission chahiye. Settings > Apps > Kholo me allow karo.", Toast.LENGTH_LONG).show()
            refreshWake()
            return
        }

        if (!Settings.canDrawOverlays(this) && !askedOverlay) {
            askedOverlay = true
            Toast.makeText(this, "Kholo ko \"Display over other apps\" allow karo, phir wapas aao.", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }

        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName) && !askedBattery) {
            askedBattery = true
            try {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
                return
            } catch (e: Exception) {
                // some phones do not have this screen: continue without it
            }
        }

        if (!ListenService.running) {
            ContextCompat.startForegroundService(this, Intent(this, ListenService::class.java))
        }
        refreshWake()
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun refreshWake() {
        val on = prefs.getBoolean("wake", false)
        wakeSwitch.isChecked = on
        wakeStatus.text = when {
            !on -> "Band hai. Chalu karoge to \"Hey Kholo\" bolkar kabhi bhi command de sakte ho."
            ListenService.running -> "Chalu hai. Bolo: \"Hey Kholo\", phir command (jaise: WhatsApp kholo)."
            else -> "Shuru ho raha hai..."
        }
    }

    private fun updateLangButton() {
        langButton.text = if (hindi) "Bolne ki bhasha: हिंदी" else "Bolne ki bhasha: English"
    }

    private fun submitText() {
        val text = input.text?.toString()?.trim().orEmpty()
        if (text.isNotEmpty()) execute(text)
    }

    private fun startVoice() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (hindi) "hi-IN" else "en-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Bolo...")
        }
        try {
            speech.launch(i)
        } catch (e: Exception) {
            status.text = "Is phone me voice input nahi mila. Neeche likhkar try karo."
        }
    }

    private fun execute(text: String) {
        val command = parser.parse(text)
        status.text = ActionExecutor.run(this, index, command)
    }
}
