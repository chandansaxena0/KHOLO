package com.example.aicommander

import android.content.Context
import java.io.File

/** Copies the voice model from the APK (assets/model) to phone storage, once. */
object ModelFiles {

    private const val VERSION = "hi-0.22-v1"

    fun ensure(context: Context): File {
        val target = File(context.filesDir, "model-$VERSION")
        val done = File(target, ".done")
        if (done.exists()) return target

        context.filesDir.listFiles()
            ?.filter { it.name.startsWith("model-") }
            ?.forEach { it.deleteRecursively() }

        target.mkdirs()
        copyDir(context, "model", target)
        done.writeText("ok")
        return target
    }

    private fun copyDir(context: Context, assetPath: String, dest: File) {
        val names = context.assets.list(assetPath) ?: return
        dest.mkdirs()
        for (name in names) {
            val child = "$assetPath/$name"
            val sub = context.assets.list(child)
            if (sub != null && sub.isNotEmpty()) {
                copyDir(context, child, File(dest, name))
            } else {
                context.assets.open(child).use { input ->
                    File(dest, name).outputStream().use { input.copyTo(it) }
                }
            }
        }
    }
}
