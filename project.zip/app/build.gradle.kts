plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.aicommander"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.aicommander"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }

    // A fixed key, so every new version installs OVER the old one (no uninstall needed after this).
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")

    // Free offline speech recognition (Apache 2.0). Used for "Hey Kholo".
    implementation("net.java.dev.jna:jna:5.18.1@aar")
    implementation("com.alphacephei:vosk-android:0.3.75@aar")
}

// ---- Downloads the free Hindi voice model during the build (not stored in the zip) ----
val modelUrl = "https://alphacephei.com/vosk/models/vosk-model-small-hi-0.22.zip"
val modelAssetDir = layout.projectDirectory.dir("src/main/assets/model").asFile

val downloadModel by tasks.registering {
    outputs.dir(modelAssetDir)
    doLast {
        if (File(modelAssetDir, "am").isDirectory) return@doLast
        modelAssetDir.deleteRecursively()
        modelAssetDir.mkdirs()
        val conn = java.net.URL(modelUrl).openConnection()
        conn.connectTimeout = 30000
        conn.readTimeout = 120000
        val root = modelAssetDir.canonicalPath
        java.util.zip.ZipInputStream(conn.getInputStream().buffered()).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                // drop the top folder name (vosk-model-small-hi-0.22/)
                val name = e.name.substringAfter('/', "")
                if (name.isNotEmpty()) {
                    val out = File(modelAssetDir, name)
                    check(out.canonicalPath.startsWith(root)) { "Bad path in model zip" }
                    if (e.isDirectory) {
                        out.mkdirs()
                    } else {
                        out.parentFile.mkdirs()
                        out.outputStream().use { zin.copyTo(it) }
                    }
                }
                e = zin.nextEntry
            }
        }
        check(File(modelAssetDir, "am").isDirectory) { "Model download failed" }
    }
}

tasks.matching { it.name.matches(Regex("merge.*Assets")) }.configureEach {
    dependsOn(downloadModel)
}
